
<p>Register</p>
<?php if (isset($errors)){echo $errors;}?>
<?php echo $reg; ?>