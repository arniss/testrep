<p>Login</p>
<?php echo $form; ?>