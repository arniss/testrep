<?php

class Controller_Map extends Controller_Template
{
        //funkcija atbild par kartes parādīšanu
	public function action_show_map()
	{
            //uzsauc funkciju, kura atjauno uzbūvetas celtnes
            Model_Map::update_buildings_done();
            //funkcija atjauno lietotaja zeltu
            $gold = Model_Map::update_gold();
            //funkcija sagatavo lietotāja uzbūvetās funkcijas tālākai padevei
            $results = Model_Map::get_built_structures();
            //funkcija iegūst celtņu tipus
            $results1 = Model_map::get_build_types();
            $view = View::forge('map/show_map');
            $view->set('results1', $results1, false);
            $view->set('results', $results, false);
            $view->set('gold', $gold);
            $this->template->content = $view;             
	    $this->template->title = 'Map &raquo; Show map';                
	}

        //funkcija atbild par to, lai būtu iespejams uzbūvetu jaunu celtni
	public function action_build()
	{                    
            $this->template->title = 'Map &raquo; Build';            
            $ur = Uri::segment(3);
            
            $results = DB::select()
            ->from('maps')
            ->where('id', $ur)
            ->and_where('user_id', Model_Map::userid())
            ->execute();
            
            $count = count($results);
 
     
            if ($count == 0)
            {
                if (Input::post())
                {
                    $ur = Uri::segment(3);
                    
                    $comment = Model_map::forge(array(
                    'user_id' => Model_Map::userid(),
                    'type' => Input::post('type'),
                    $type = Input::post('type'),
                    'name' => Input::post('name'),
                    'id' =>  $ur,
                    ));
                    
                    //ja lietotajam pietiek zelta celtnes būvniecībai ta tiek sakta būvēt
                    if (Model_Map::validate_cost($type) == true)
                        { 
                        if ($comment and $comment->save())
                        {
                            Session::set_flash('success', 'Added comment #'.$comment->id.'.');
                            Response::redirect('map/show_map/'.$comment->id);
                
                        }
                        else
                        {
                            Session::set_flash('error', 'Could not save comment.');
                        }
                        }
                    else
                    {
                        Session::set_flash('error', 'Not enough gold');
                        $this->template->content = View::forge('map/build');
                    }
             
                }
             else {$this->template->content = View::forge('map/build');}
             }
             else
             {          
                $this->template->content = View::forge('map/built');
                echo "jau bija saglabats";
                echo "Time till building is done:";
                $buildinid = $ur;
                if (Model_Map::get_remaining_time($buildinid) < 0)
                {
                    echo "building done";
                }
       
               }

        }

}
