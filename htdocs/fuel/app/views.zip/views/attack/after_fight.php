<?php
echo 'u won ';
echo $stats[0];
echo ' gold</br>';
echo ' Lost ';
echo $stats[1];
echo ' marines';
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
